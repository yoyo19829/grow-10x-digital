//#region \0tanstack-start-manifest:v
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Admin/Downloads/grow-10x-digital/src/routes/__root.tsx",
		children: [
			"/",
			"/blogs/$slug",
			"/blogs/"
		],
		preloads: ["/assets/index-CKdMQXOd.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CKdMQXOd.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Admin/Downloads/grow-10x-digital/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BluvqbkM.js", "/assets/nav-CCVSmySo.js"]
	},
	"/blogs/$slug": {
		filePath: "C:/Users/Admin/Downloads/grow-10x-digital/src/routes/blogs/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-BnkLFqyN.js", "/assets/nav-CCVSmySo.js"]
	},
	"/blogs/": {
		filePath: "C:/Users/Admin/Downloads/grow-10x-digital/src/routes/blogs/index.tsx",
		children: void 0,
		preloads: ["/assets/blogs-DGBCwQrn.js", "/assets/nav-CCVSmySo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
