//#region src/lib/leads-webhook.ts
var WEBHOOK_URL = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_GOOGLE_SHEETS_WEBHOOK_URL"] || "https://script.google.com/macros/s/AKfycbxdl3oAYq7RQtpHrtBwKvqcBObLAAnV3KfnST3BNuZ9ooq7YVu7b37GCjgvQMd68NEs/exec";
async function submitLead(data) {
	try {
		const response = await fetch(WEBHOOK_URL, {
			method: "POST",
			headers: { "Content-Type": "text/plain;charset=utf-8" },
			body: JSON.stringify({
				timestamp: (/* @__PURE__ */ new Date()).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
				name: data.name,
				company: data.company,
				email: data.email,
				mobile: data.mobile,
				city: data.city
			}),
			redirect: "follow"
		});
		if (!response.ok) {
			console.error("Google Sheets error:", response.status);
			return {
				ok: false,
				error: "Unable to submit your details. Please try again."
			};
		}
		return { ok: true };
	} catch (err) {
		console.error("Lead submission error:", err);
		return {
			ok: false,
			error: "Network error. Please try again or call us directly."
		};
	}
}
//#endregion
export { submitLead };
