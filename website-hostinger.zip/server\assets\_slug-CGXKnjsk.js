import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region src/routes/blogs/$slug.tsx
var $$splitComponentImporter = () => import("./_slug-1e-jQt0G.js");
var Route = createFileRoute("/blogs/$slug")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
