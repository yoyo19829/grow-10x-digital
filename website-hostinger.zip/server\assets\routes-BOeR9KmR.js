import { n as BrandLogo, t as Nav } from "./nav-C197z1EM.js";
import { useEffect, useRef, useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { toast } from "sonner";
import { ArrowRight, Building2, CheckCircle2, CircleCheck, ClipboardCheck, Clock3, Cpu, Mail, MapPin, Megaphone, MessageCircle, Monitor, Palette, Phone, Rocket, Sparkles, Star, Target, TrendingDown, TrendingUp, UserRoundCheck, Users, Zap } from "lucide-react";
//#region src/components/counter.tsx
function Counter({ target, prefix = "", suffix = "", duration = 1800 }) {
	const [value, setValue] = useState(0);
	const ref = useRef(null);
	const started = useRef(false);
	useEffect(() => {
		const el = ref.current;
		if (!el) return;
		const io = new IntersectionObserver((entries) => {
			entries.forEach((e) => {
				if (e.isIntersecting && !started.current) {
					started.current = true;
					const start = performance.now();
					const tick = (now) => {
						const p = Math.min(1, (now - start) / duration);
						const eased = 1 - Math.pow(1 - p, 3);
						setValue(Math.round(target * eased));
						if (p < 1) requestAnimationFrame(tick);
					};
					requestAnimationFrame(tick);
				}
			});
		}, { threshold: .4 });
		io.observe(el);
		return () => io.disconnect();
	}, [target, duration]);
	return /* @__PURE__ */ jsxs("span", {
		ref,
		children: [
			prefix,
			value,
			suffix
		]
	});
}
//#endregion
//#region src/components/hero.tsx
function Hero() {
	return /* @__PURE__ */ jsxs("section", {
		className: "bg-hero relative pt-40 pb-28 px-6 overflow-hidden",
		children: [
			/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute -top-24 -left-24 h-96 w-96 rounded-full bg-orange/30 blur-3xl animate-glow-pulse" }),
			/* @__PURE__ */ jsx("div", {
				className: "pointer-events-none absolute top-1/3 -right-24 h-[28rem] w-[28rem] rounded-full bg-navy/25 blur-3xl animate-glow-pulse",
				style: { animationDelay: "1.5s" }
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "relative max-w-6xl mx-auto text-center",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs font-semibold text-navy-deep mb-8",
						children: [/* @__PURE__ */ jsx(Sparkles, { className: "h-3.5 w-3.5 text-orange" }), "ROI-Driven Growth Company"]
					}),
					/* @__PURE__ */ jsxs("h1", {
						className: "text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.02] tracking-tight",
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "text-gradient-brand",
								children: "Grow 10X"
							}),
							/* @__PURE__ */ jsx("span", {
								className: "text-navy-deep",
								children: " with Marketing, Technology & AI"
							}),
							/* @__PURE__ */ jsx("span", {
								className: "text-orange",
								children: "."
							})
						]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-8 max-w-2xl mx-auto text-lg text-muted-foreground",
						children: "We're Bedifly—a ROI-driven growth company helping businesses scale with performance marketing, technology, and AI. With 10+ years of combined experience, 100+ businesses served, and 7X+ average ROAS, we focus on generating measurable leads, sales, and profitable growth."
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-10 flex flex-col sm:flex-row items-center justify-center gap-4",
						children: [/* @__PURE__ */ jsxs("a", {
							href: "#contact",
							className: "group bg-navy-deep text-primary-foreground rounded-full px-7 py-4 text-base font-semibold shadow-navy hover:shadow-glow transition-all inline-flex items-center gap-2",
							children: ["Book a Strategy Call", /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4 group-hover:translate-x-1 transition" })]
						}), /* @__PURE__ */ jsx("a", {
							href: "#services",
							className: "bg-white/70 backdrop-blur border border-border text-navy-deep rounded-full px-7 py-4 text-base font-semibold hover:bg-white transition",
							children: "Explore Services"
						})]
					}),
					/* @__PURE__ */ jsx("div", {
						className: "mt-16 grid grid-cols-3 gap-4 max-w-3xl mx-auto",
						children: [
							{
								target: 10,
								suffix: "+",
								label: "Years scaling brands"
							},
							{
								target: 100,
								suffix: "+",
								label: "Brands served"
							},
							{
								target: 10,
								prefix: "",
								suffix: "Cr+",
								label: "Ad spend managed"
							}
						].map((s) => /* @__PURE__ */ jsxs("div", {
							className: "glass rounded-2xl p-5 shadow-soft",
							children: [/* @__PURE__ */ jsx("div", {
								className: "text-3xl md:text-4xl font-bold text-gradient-brand",
								children: /* @__PURE__ */ jsx(Counter, {
									target: s.target,
									prefix: s.prefix,
									suffix: s.suffix
								})
							}), /* @__PURE__ */ jsx("div", {
								className: "text-xs md:text-sm text-muted-foreground mt-1",
								children: s.label
							})]
						}, s.label))
					})
				]
			})
		]
	});
}
//#endregion
//#region src/components/why-bedifly.tsx
var problems = [
	{
		q: "Not enough qualified leads?",
		a: "Your marketing may not be reaching the right audience."
	},
	{
		q: "Getting traffic but no conversions?",
		a: "Your website may not be turning visitors into customers."
	},
	{
		q: "Spending too much time on repetitive work?",
		a: "Your business may need smarter automation."
	},
	{
		q: "Using disconnected tools and systems?",
		a: "Your technology should work together—not against you."
	},
	{
		q: "Struggling to scale?",
		a: "You need a growth system built around measurable results."
	}
];
function WhyBedifly() {
	return /* @__PURE__ */ jsxs("section", {
		className: "relative py-24 px-6 bg-navy-deep text-primary-foreground overflow-hidden",
		children: [
			/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute -bottom-24 -right-24 h-96 w-96 rounded-full bg-orange/20 blur-3xl" }),
			/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute top-0 -left-24 h-80 w-80 rounded-full bg-orange/10 blur-3xl" }),
			/* @__PURE__ */ jsxs("div", {
				className: "relative max-w-6xl mx-auto grid gap-12 lg:grid-cols-2 lg:gap-16 items-center",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ jsx("div", {
							className: "text-xs uppercase tracking-[0.2em] text-orange font-bold mb-4",
							children: "Why Bedifly"
						}),
						/* @__PURE__ */ jsx("h2", {
							className: "text-3xl md:text-5xl font-extrabold leading-[1.1] tracking-tight",
							children: "Your Business Needs More Than Just Marketing"
						}),
						/* @__PURE__ */ jsx("p", {
							className: "mt-6 text-base md:text-lg text-primary-foreground/70 max-w-md",
							children: "Getting customers today requires more than running ads or having a website."
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "mt-8 inline-flex items-center gap-2 text-orange font-semibold text-lg",
							children: ["That's where Bedifly comes in.", /* @__PURE__ */ jsx(ArrowRight, { className: "h-5 w-5" })]
						})
					]
				}), /* @__PURE__ */ jsx("div", {
					className: "space-y-3",
					children: problems.map((p) => /* @__PURE__ */ jsx("div", {
						className: "rounded-2xl p-5 bg-white/[0.06] border border-white/10 hover:bg-white/[0.1] hover:border-orange/40 transition-colors",
						children: /* @__PURE__ */ jsxs("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ jsx(ArrowRight, { className: "mt-1 h-5 w-5 shrink-0 text-orange" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
								className: "font-semibold text-primary-foreground/95",
								children: p.q
							}), /* @__PURE__ */ jsx("p", {
								className: "text-sm text-primary-foreground/65 mt-1",
								children: p.a
							})] })]
						})
					}, p.q))
				})]
			})
		]
	});
}
//#endregion
//#region src/components/services.tsx
var services = [
	{
		title: "Performance Marketing",
		description: "Data-driven campaigns focused on profitable growth, better acquisition costs, and measurable ROI.",
		tags: [
			"ROI-Focused",
			"Audience Research",
			"Campaign Optimization",
			"Performance Tracking"
		],
		icon: TrendingUp
	},
	{
		title: "Website Development",
		description: "Fast, responsive, conversion-focused websites designed to turn visitors into enquiries and customers.",
		tags: [
			"Mobile-First",
			"Conversion-Focused",
			"SEO-Ready",
			"Fast & Responsive"
		],
		icon: Monitor
	},
	{
		title: "AI Automation",
		description: "Intelligent systems that automate lead management, customer communication, and repetitive business workflows.",
		tags: [
			"AI Workflows",
			"Lead Qualification",
			"Automated Follow-Ups",
			"24/7 Automation"
		],
		icon: Sparkles
	},
	{
		title: "Lead Generation",
		description: "Build a predictable pipeline of qualified prospects while improving both lead volume and lead quality.",
		tags: [
			"Qualified Leads",
			"Multi-Channel",
			"Lead Tracking",
			"Conversion-Focused"
		],
		icon: Target
	},
	{
		title: "Google & Meta Ads",
		description: "Reach the right customers with strategic targeting, creative testing, conversion tracking, and optimization.",
		tags: [
			"Google Ads",
			"Meta Ads",
			"Retargeting",
			"Conversion Tracking"
		],
		icon: Megaphone
	},
	{
		title: "WhatsApp Automation",
		description: "Automate responses, qualification, follow-ups, reminders, and customer conversations on WhatsApp.",
		tags: [
			"24/7 Responses",
			"AI Conversations",
			"Lead Qualification",
			"Automated Follow-Ups"
		],
		icon: MessageCircle
	}
];
function Services() {
	return /* @__PURE__ */ jsx("section", {
		id: "services",
		className: "relative py-20 px-6",
		children: /* @__PURE__ */ jsxs("div", {
			className: "max-w-6xl mx-auto",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "text-center max-w-3xl mx-auto",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "text-[11px] uppercase tracking-[0.18em] text-orange font-bold mb-3",
						children: "What We Do"
					}),
					/* @__PURE__ */ jsxs("h2", {
						className: "text-4xl md:text-5xl font-extrabold text-navy-deep leading-tight",
						children: [
							"Everything you need to",
							" ",
							/* @__PURE__ */ jsx("span", {
								className: "text-gradient-orange",
								children: "grow 10x."
							})
						]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-4 text-sm md:text-base text-muted-foreground",
						children: "Six core services working together to drive measurable business growth."
					})
				]
			}), /* @__PURE__ */ jsx("div", {
				className: "mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
				children: services.map((s, i) => {
					const Icon = s.icon;
					return /* @__PURE__ */ jsxs("div", {
						className: "group relative rounded-[1.5rem] border border-border bg-card p-6 shadow-soft hover:shadow-navy hover:-translate-y-1 hover:border-orange/40 transition-all overflow-hidden",
						style: { transitionDelay: `${i * 40}ms` },
						children: [/* @__PURE__ */ jsx("div", { className: "absolute -top-20 -right-20 h-40 w-40 rounded-full bg-orange/10 blur-3xl group-hover:bg-orange/20 transition" }), /* @__PURE__ */ jsxs("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "relative flex items-center justify-center shrink-0",
										children: [/* @__PURE__ */ jsx("div", { className: "absolute h-12 w-12 rounded-full bg-orange/20 blur-md group-hover:bg-orange/30 transition" }), /* @__PURE__ */ jsx("div", {
											className: "relative flex h-11 w-11 items-center justify-center rounded-full bg-orange-gradient text-white shadow-glow group-hover:scale-105 transition-transform",
											children: /* @__PURE__ */ jsx(Icon, {
												className: "h-5 w-5",
												strokeWidth: 2.2
											})
										})]
									}), /* @__PURE__ */ jsx("h3", {
										className: "text-lg font-bold text-navy-deep",
										children: s.title
									})]
								}),
								/* @__PURE__ */ jsx("p", {
									className: "mt-4 text-xs md:text-sm leading-relaxed text-muted-foreground",
									children: s.description
								}),
								/* @__PURE__ */ jsx("div", {
									className: "mt-5 flex flex-wrap gap-1.5",
									children: s.tags.map((tag) => /* @__PURE__ */ jsx("span", {
										className: "inline-flex items-center rounded-full bg-orange/10 px-2.5 py-1 text-[10px] font-medium text-navy-deep/80 group-hover:bg-orange/15 transition-colors",
										children: tag
									}, tag))
								}),
								/* @__PURE__ */ jsxs("a", {
									href: "#contact",
									className: "mt-5 inline-flex items-center gap-2 text-xs font-semibold text-navy-deep group-hover:text-orange transition-colors",
									children: ["Get Started", /* @__PURE__ */ jsx(ArrowRight, { className: "h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" })]
								})
							]
						})]
					}, s.title);
				})
			})]
		})
	});
}
//#endregion
//#region src/components/growth-system.tsx
var stages = [
	{
		number: "01",
		title: "Traffic",
		icon: Megaphone,
		description: "Reach the right audience through Google, Meta, and targeted campaigns."
	},
	{
		number: "02",
		title: "Leads",
		icon: UserRoundCheck,
		description: "Turn attention into enquiries through landing pages, forms, and campaigns."
	},
	{
		number: "03",
		title: "Qualification",
		icon: Cpu,
		description: "Identify high-intent prospects using qualification, AI, and automation."
	},
	{
		number: "04",
		title: "Conversion",
		icon: CircleCheck,
		description: "Turn qualified prospects into customers through better sales journeys."
	},
	{
		number: "05",
		title: "Automation",
		icon: Zap,
		description: "Automate repetitive marketing and customer processes with AI."
	},
	{
		number: "06",
		title: "Revenue",
		icon: TrendingUp,
		description: "Measure ROI and continuously optimize for scalable business growth."
	}
];
function GrowthSystem() {
	return /* @__PURE__ */ jsxs("section", {
		className: "relative py-20 px-6 overflow-hidden",
		children: [/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-orange/[0.02] to-navy/[0.04]" }), /* @__PURE__ */ jsxs("div", {
			className: "relative max-w-6xl mx-auto",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "text-center max-w-3xl mx-auto",
					children: [
						/* @__PURE__ */ jsx("div", {
							className: "text-[11px] uppercase tracking-[0.18em] text-orange font-bold mb-3",
							children: "✦ Our Growth System"
						}),
						/* @__PURE__ */ jsxs("h2", {
							className: "text-4xl md:text-5xl font-extrabold text-navy-deep leading-tight",
							children: ["How We ", /* @__PURE__ */ jsx("span", {
								className: "text-gradient-orange",
								children: "Drive Growth"
							})]
						}),
						/* @__PURE__ */ jsx("p", {
							className: "mt-4 text-sm md:text-base text-muted-foreground leading-relaxed max-w-2xl mx-auto",
							children: "We connect marketing, technology, and AI into one system that turns attention into measurable revenue."
						})
					]
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-10 rounded-[1.75rem] bg-white/80 backdrop-blur-xl border border-white/70 shadow-soft px-5 py-4 overflow-x-auto",
					children: /* @__PURE__ */ jsx("div", {
						className: "flex items-center min-w-[850px]",
						children: stages.map((stage, index) => {
							const Icon = stage.icon;
							const isLast = index === stages.length - 1;
							return /* @__PURE__ */ jsxs("div", {
								className: "flex items-center flex-1 min-w-0",
								children: [/* @__PURE__ */ jsxs("div", {
									className: "flex items-center gap-2.5 whitespace-nowrap",
									children: [/* @__PURE__ */ jsx("div", {
										className: `h-9 w-9 rounded-full grid place-items-center shrink-0 ${isLast ? "bg-orange text-white shadow-glow" : "bg-navy-deep text-white"}`,
										children: /* @__PURE__ */ jsx(Icon, { className: "h-4 w-4" })
									}), /* @__PURE__ */ jsxs("span", {
										className: `text-xs font-bold ${isLast ? "text-orange" : "text-navy-deep"}`,
										children: [
											stage.number,
											" ",
											stage.title
										]
									})]
								}), !isLast && /* @__PURE__ */ jsx("div", {
									className: "relative flex-1 mx-3 h-px bg-gradient-to-r from-border to-orange/40",
									children: /* @__PURE__ */ jsx(ArrowRight, { className: "absolute right-0 -top-2 h-4 w-4 text-orange" })
								})]
							}, stage.number);
						})
					})
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-6",
					children: stages.map((stage, index) => {
						const Icon = stage.icon;
						const isRevenue = index === stages.length - 1;
						return /* @__PURE__ */ jsxs("div", {
							className: `group relative min-h-[270px] rounded-[1.5rem] p-5 flex flex-col overflow-hidden transition-all duration-300 hover:-translate-y-1 ${isRevenue ? "bg-navy-deep border-2 border-orange shadow-glow text-white" : "bg-white/90 border border-border shadow-soft hover:shadow-navy"}`,
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ jsx("span", {
										className: `inline-flex items-center rounded-full px-2.5 py-1 text-[10px] font-bold ${isRevenue ? "bg-orange/20 text-orange" : "bg-navy-deep/5 text-navy-deep"}`,
										children: stage.number
									}), /* @__PURE__ */ jsx("div", {
										className: `h-11 w-11 rounded-full grid place-items-center ${isRevenue ? "bg-orange text-white shadow-glow" : "bg-orange/10 text-orange"}`,
										children: /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5" })
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "mt-7",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ jsx("h3", {
											className: `text-lg font-bold ${isRevenue ? "text-white" : "text-navy-deep"}`,
											children: stage.title
										}), isRevenue && /* @__PURE__ */ jsx("span", {
											className: "rounded-full bg-orange px-2 py-0.5 text-[9px] font-bold text-white",
											children: "GOAL"
										})]
									}), /* @__PURE__ */ jsx("p", {
										className: `mt-3 text-xs leading-relaxed ${isRevenue ? "text-white/75" : "text-muted-foreground"}`,
										children: stage.description
									})]
								}),
								/* @__PURE__ */ jsx("div", {
									className: `mt-auto pt-5 flex justify-end ${isRevenue ? "text-orange" : "text-navy-deep"}`,
									children: /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })
								})
							]
						}, stage.number);
					})
				})
			]
		})]
	});
}
//#endregion
//#region src/components/case-studies.tsx
function CaseStudies() {
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("section", {
		id: "case-studies",
		className: "relative py-20 px-6 overflow-hidden",
		children: [/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-orange/[0.02] to-navy/[0.04]" }), /* @__PURE__ */ jsxs("div", {
			className: "relative max-w-6xl mx-auto",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "text-center max-w-3xl mx-auto",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "text-xs uppercase tracking-[0.2em] text-orange font-bold mb-3",
						children: "✣ Case Study"
					}),
					/* @__PURE__ */ jsxs("h2", {
						className: "text-4xl md:text-5xl font-extrabold text-navy-deep leading-tight",
						children: [
							"Proven Growth.",
							" ",
							/* @__PURE__ */ jsx("span", {
								className: "text-gradient-orange",
								children: "Measurable Results."
							})
						]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-4 text-sm md:text-base text-muted-foreground leading-relaxed",
						children: "How strategic performance marketing reduced acquisition costs, improved lead quality, and increased conversions."
					})
				]
			}), /* @__PURE__ */ jsx("div", {
				className: "mt-12 rounded-[2rem] border border-border bg-white/90 shadow-soft overflow-hidden",
				children: /* @__PURE__ */ jsxs("div", {
					className: "p-6 md:p-8",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex flex-col md:flex-row md:items-center md:justify-between gap-5",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ jsx("div", {
									className: "h-12 w-12 rounded-xl bg-white border border-border shadow-soft grid place-items-center shrink-0",
									children: /* @__PURE__ */ jsx(Building2, { className: "h-6 w-6 text-navy-deep" })
								}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("div", {
									className: "flex items-center gap-2 text-orange text-[10px] font-bold uppercase tracking-wider",
									children: [/* @__PURE__ */ jsx(Building2, { className: "h-3.5 w-3.5" }), "Real Estate"]
								}), /* @__PURE__ */ jsx("h3", {
									className: "mt-1 text-xl md:text-2xl font-extrabold text-navy-deep",
									children: "Indian Property Expert"
								})] })]
							}), /* @__PURE__ */ jsxs("div", {
								className: "flex flex-wrap items-center gap-3 md:gap-5",
								children: [/* @__PURE__ */ jsxs("div", {
									className: "text-xs md:text-sm font-semibold text-navy-deep",
									children: [
										"Project Value:",
										" ",
										/* @__PURE__ */ jsx("span", {
											className: "text-orange",
											children: "₹1.5 Crore / ~$156.7K"
										})
									]
								}), /* @__PURE__ */ jsxs("div", {
									className: "inline-flex items-center gap-2 rounded-full bg-navy-deep px-4 py-2.5 text-xs font-bold text-white",
									children: [/* @__PURE__ */ jsx(Clock3, { className: "h-3.5 w-3.5 text-orange" }), "30-day improvement"]
								})]
							})]
						}),
						/* @__PURE__ */ jsx("div", { className: "mt-7 h-px bg-border" }),
						/* @__PURE__ */ jsxs("div", {
							className: "mt-7 grid md:grid-cols-2 gap-5",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "rounded-2xl border border-orange/15 bg-orange/[0.035] p-5",
								children: [
									/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ jsx(Target, { className: "h-4 w-4 text-orange" }), /* @__PURE__ */ jsx("span", {
											className: "text-xs font-bold uppercase tracking-wider text-orange",
											children: "The Challenge"
										})]
									}),
									/* @__PURE__ */ jsx("h4", {
										className: "mt-3 text-lg font-extrabold text-navy-deep",
										children: "High CPL. Low conversion."
									}),
									/* @__PURE__ */ jsxs("div", {
										className: "mt-3 space-y-2",
										children: [
											/* @__PURE__ */ jsxs("div", {
												className: "flex items-center gap-2 text-xs text-navy-deep",
												children: [/* @__PURE__ */ jsx("span", {
													className: "text-orange",
													children: "•"
												}), "CPL was too high for the target city"]
											}),
											/* @__PURE__ */ jsxs("div", {
												className: "flex items-center gap-2 text-xs text-navy-deep",
												children: [/* @__PURE__ */ jsx("span", {
													className: "text-orange",
													children: "•"
												}), "Low percentage of leads were converting"]
											}),
											/* @__PURE__ */ jsxs("div", {
												className: "flex items-center gap-2 text-xs text-navy-deep",
												children: [/* @__PURE__ */ jsx("span", {
													className: "text-orange",
													children: "•"
												}), "Too many low-intent enquiries"]
											})
										]
									})
								]
							}), /* @__PURE__ */ jsxs("div", {
								className: "rounded-2xl border border-border bg-background/70 p-5",
								children: [
									/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4 text-orange" }), /* @__PURE__ */ jsx("span", {
											className: "text-xs font-bold uppercase tracking-wider text-orange",
											children: "Our Solution"
										})]
									}),
									/* @__PURE__ */ jsx("h4", {
										className: "mt-3 text-lg font-extrabold text-navy-deep",
										children: "Better creatives. Better leads."
									}),
									/* @__PURE__ */ jsxs("div", {
										className: "mt-3 space-y-3",
										children: [
											/* @__PURE__ */ jsxs("div", {
												className: "flex items-start gap-2",
												children: [/* @__PURE__ */ jsx(Palette, { className: "h-4 w-4 text-orange mt-0.5 shrink-0" }), /* @__PURE__ */ jsxs("p", {
													className: "text-xs text-muted-foreground leading-relaxed",
													children: [
														/* @__PURE__ */ jsx("strong", {
															className: "text-navy-deep",
															children: "New hooks & creatives"
														}),
														" ",
														"built to attract the right audience and improve campaign efficiency."
													]
												})]
											}),
											/* @__PURE__ */ jsxs("div", {
												className: "flex items-start gap-2",
												children: [/* @__PURE__ */ jsx(ClipboardCheck, { className: "h-4 w-4 text-orange mt-0.5 shrink-0" }), /* @__PURE__ */ jsxs("p", {
													className: "text-xs text-muted-foreground leading-relaxed",
													children: [
														/* @__PURE__ */ jsx("strong", {
															className: "text-navy-deep",
															children: "4 qualifying questions"
														}),
														" ",
														"added before submission to filter low-intent leads."
													]
												})]
											}),
											/* @__PURE__ */ jsxs("div", {
												className: "flex items-start gap-2",
												children: [/* @__PURE__ */ jsx(TrendingUp, { className: "h-4 w-4 text-orange mt-0.5 shrink-0" }), /* @__PURE__ */ jsxs("p", {
													className: "text-xs text-muted-foreground leading-relaxed",
													children: [
														"Focus shifted from",
														" ",
														/* @__PURE__ */ jsx("strong", {
															className: "text-navy-deep",
															children: "lead quantity to lead quality"
														}),
														" ",
														"and conversion potential."
													]
												})]
											})
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "mt-6 grid md:grid-cols-2 gap-5",
							children: [/* @__PURE__ */ jsx(MetricCard, {
								title: "Cost Per Lead",
								improvement: "67.57% lower",
								improvementIcon: TrendingDown,
								before: "₹370",
								after: "₹120"
							}), /* @__PURE__ */ jsx(MetricCard, {
								title: "Conversion Rate",
								improvement: "125% improvement",
								improvementIcon: TrendingUp,
								before: "2%",
								after: "4.5%"
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mt-6 rounded-2xl bg-navy-deep px-6 py-5 text-white",
							children: /* @__PURE__ */ jsxs("div", {
								className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4",
								children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
									className: "text-[10px] uppercase tracking-[0.18em] font-bold text-orange",
									children: "Return on Ad Spend"
								}), /* @__PURE__ */ jsxs("div", {
									className: "mt-1 flex items-baseline gap-2",
									children: [/* @__PURE__ */ jsx("span", {
										className: "text-4xl md:text-5xl font-extrabold",
										children: "50X"
									}), /* @__PURE__ */ jsx("span", {
										className: "text-xl font-bold text-orange",
										children: "ROAS"
									})]
								})] }), /* @__PURE__ */ jsxs("a", {
									href: "#contact",
									className: "inline-flex items-center justify-center gap-2 rounded-full bg-orange-gradient px-5 py-3 text-xs font-bold text-white shadow-glow hover:opacity-95 transition",
									children: ["Scale Your Brand", /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })]
								})]
							})
						})
					]
				})
			})]
		})]
	}), /* @__PURE__ */ jsxs("section", {
		id: "founder",
		className: "relative py-16 px-6 overflow-hidden",
		children: [/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-orange/[0.02] to-navy/[0.03]" }), /* @__PURE__ */ jsxs("div", {
			className: "relative max-w-6xl mx-auto",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "text-center max-w-3xl mx-auto",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "text-[11px] uppercase tracking-[0.18em] text-orange font-bold mb-3",
						children: "Meet The Founder"
					}),
					/* @__PURE__ */ jsxs("h2", {
						className: "text-4xl md:text-5xl font-extrabold text-navy-deep leading-tight",
						children: [
							"The person behind",
							" ",
							/* @__PURE__ */ jsx("span", {
								className: "text-gradient-orange",
								children: "10X Digital."
							})
						]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-4 text-sm md:text-base text-muted-foreground",
						children: "Engineering mindset. Marketing experience. Technology-driven growth."
					})
				]
			}), /* @__PURE__ */ jsx("div", {
				className: "mt-10 rounded-[2rem] border border-border bg-white/90 shadow-soft overflow-hidden",
				children: /* @__PURE__ */ jsx("div", {
					className: "p-6 md:p-8",
					children: /* @__PURE__ */ jsxs("div", {
						className: "grid md:grid-cols-[250px_1fr] gap-8 md:gap-10 items-center",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "relative w-full max-w-[250px] mx-auto md:mx-0",
							children: [/* @__PURE__ */ jsx("div", { className: "absolute -inset-2 rounded-[1.5rem] bg-orange/10 blur-xl" }), /* @__PURE__ */ jsx("div", {
								className: "relative overflow-hidden rounded-[1.5rem] border border-border bg-card",
								children: /* @__PURE__ */ jsx("img", {
									src: "/founder.jpeg",
									alt: "Aashutosh Sharma - Founder of 10X Digital",
									className: "w-full aspect-[4/5] object-cover"
								})
							})]
						}), /* @__PURE__ */ jsxs("div", { children: [
							/* @__PURE__ */ jsx("div", {
								className: "text-[10px] uppercase tracking-[0.18em] text-orange font-bold",
								children: "Founder"
							}),
							/* @__PURE__ */ jsx("h3", {
								className: "mt-1 text-2xl md:text-3xl font-extrabold text-navy-deep",
								children: "Aashutosh Sharma"
							}),
							/* @__PURE__ */ jsx("div", {
								className: "mt-1 text-xs md:text-sm font-medium text-muted-foreground",
								children: "Growth Strategist • Technology • Performance Marketing"
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-5 space-y-3",
								children: [
									/* @__PURE__ */ jsx("p", {
										className: "text-xs md:text-sm leading-relaxed text-muted-foreground",
										children: "Aashutosh started out with an engineering degree, but soon discovered his real passion at the cross-section of code, market trends, and advertising. Over the past 10+ years, he has turned analytical thinking and strategic testing into systems that drive real business growth."
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-xs md:text-sm leading-relaxed text-muted-foreground",
										children: "His philosophy is simple: technology and fancy copy mean little if you aren't reaching the right person at the right moment."
									}),
									/* @__PURE__ */ jsxs("p", {
										className: "text-xs md:text-sm leading-relaxed text-muted-foreground",
										children: [
											"Following that principle, he has helped businesses generate",
											" ",
											/* @__PURE__ */ jsx("span", {
												className: "font-bold text-navy-deep",
												children: "1 Lakh+ high-quality leads"
											}),
											" ",
											"across Meta, Google, and WhatsApp, while maintaining an average",
											" ",
											/* @__PURE__ */ jsx("span", {
												className: "font-bold text-orange",
												children: "7x ROAS."
											})
										]
									})
								]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-6 grid grid-cols-3 gap-2 md:gap-3",
								children: [
									/* @__PURE__ */ jsxs("div", {
										className: "rounded-xl border border-border bg-background/70 px-3 py-3",
										children: [
											/* @__PURE__ */ jsx(TrendingUp, { className: "h-4 w-4 text-orange mb-1.5" }),
											/* @__PURE__ */ jsx("div", {
												className: "text-lg font-extrabold text-navy-deep",
												children: "7x"
											}),
											/* @__PURE__ */ jsx("div", {
												className: "text-[9px] md:text-[10px] text-muted-foreground",
												children: "Average ROAS"
											})
										]
									}),
									/* @__PURE__ */ jsxs("div", {
										className: "rounded-xl border border-border bg-background/70 px-3 py-3",
										children: [
											/* @__PURE__ */ jsx(Users, { className: "h-4 w-4 text-orange mb-1.5" }),
											/* @__PURE__ */ jsx("div", {
												className: "text-lg font-extrabold text-navy-deep",
												children: "1L+"
											}),
											/* @__PURE__ */ jsx("div", {
												className: "text-[9px] md:text-[10px] text-muted-foreground",
												children: "Leads Generated"
											})
										]
									}),
									/* @__PURE__ */ jsxs("div", {
										className: "rounded-xl border border-border bg-background/70 px-3 py-3",
										children: [
											/* @__PURE__ */ jsx(Zap, { className: "h-4 w-4 text-orange mb-1.5" }),
											/* @__PURE__ */ jsx("div", {
												className: "text-lg font-extrabold text-navy-deep",
												children: "10+"
											}),
											/* @__PURE__ */ jsx("div", {
												className: "text-[9px] md:text-[10px] text-muted-foreground",
												children: "Years Experience"
											})
										]
									})
								]
							}),
							/* @__PURE__ */ jsx("div", {
								className: "mt-5 rounded-xl border border-orange/15 bg-orange/[0.035] px-4 py-3",
								children: /* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-2.5",
									children: [/* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4 text-orange shrink-0 mt-0.5" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
										className: "text-[9px] uppercase tracking-wider font-bold text-orange",
										children: "His Philosophy"
									}), /* @__PURE__ */ jsx("p", {
										className: "mt-1 text-xs italic leading-relaxed text-navy-deep",
										children: "\"Your marketing expectations always have to line up with the budget you bring to the table.\""
									})] })]
								})
							}),
							/* @__PURE__ */ jsxs("a", {
								href: "#contact",
								className: "mt-5 inline-flex items-center gap-2 rounded-full bg-orange-gradient px-5 py-2.5 text-xs font-bold text-white shadow-glow hover:opacity-95 transition",
								children: ["Talk to Aashutosh", /* @__PURE__ */ jsx(ArrowRight, { className: "h-3.5 w-3.5" })]
							})
						] })]
					})
				})
			})]
		})]
	})] });
}
function MetricCard({ title, improvement, improvementIcon: ImprovementIcon, before, after }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "rounded-2xl border border-border bg-background/70 px-5 py-5",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ jsx("div", {
				className: "text-xs font-bold uppercase tracking-wider text-navy-deep",
				children: title
			}), /* @__PURE__ */ jsxs("div", {
				className: "inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-3 py-1.5 text-[10px] font-bold text-emerald-600",
				children: [/* @__PURE__ */ jsx(ImprovementIcon, { className: "h-3 w-3" }), improvement]
			})]
		}), /* @__PURE__ */ jsxs("div", {
			className: "mt-5 flex items-center justify-between",
			children: [
				/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
					className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
					children: "Before"
				}), /* @__PURE__ */ jsx("div", {
					className: "mt-1 text-3xl font-extrabold text-navy-deep/60 line-through decoration-orange",
					children: before
				})] }),
				/* @__PURE__ */ jsx(ArrowRight, { className: "h-6 w-6 text-orange" }),
				/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
					className: "text-[10px] font-semibold uppercase tracking-wider text-orange",
					children: "After"
				}), /* @__PURE__ */ jsx("div", {
					className: "mt-1 text-3xl font-extrabold text-navy-deep",
					children: after
				})] })
			]
		})]
	});
}
//#endregion
//#region src/components/about.tsx
function About() {
	return /* @__PURE__ */ jsx("section", {
		id: "about",
		className: "relative py-28 px-6 bg-secondary/40",
		children: /* @__PURE__ */ jsxs("div", {
			className: "max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "relative",
				children: [/* @__PURE__ */ jsx("div", { className: "absolute -inset-6 bg-brand-gradient opacity-20 blur-3xl rounded-[3rem]" }), /* @__PURE__ */ jsx("div", {
					className: "relative rounded-[2rem] bg-brand-gradient p-1 shadow-navy",
					children: /* @__PURE__ */ jsxs("div", {
						className: "rounded-[calc(2rem-4px)] bg-navy-deep p-10 text-primary-foreground",
						children: [
							/* @__PURE__ */ jsx(Rocket, { className: "h-10 w-10 text-orange animate-float-slower" }),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-8 text-5xl md:text-6xl font-bold leading-none",
								children: ["10", /* @__PURE__ */ jsx("span", {
									className: "text-orange",
									children: "x"
								})]
							}),
							/* @__PURE__ */ jsx("p", {
								className: "mt-2 text-white/70",
								children: "Average growth of our top clients within 12 months."
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-10 grid grid-cols-2 gap-6",
								children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
									className: "text-3xl font-bold text-orange",
									children: "98%"
								}), /* @__PURE__ */ jsx("div", {
									className: "text-xs text-white/60 uppercase tracking-widest mt-1",
									children: "Client retention"
								})] }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
									className: "text-3xl font-bold text-orange",
									children: "30+"
								}), /* @__PURE__ */ jsx("div", {
									className: "text-xs text-white/60 uppercase tracking-widest mt-1",
									children: "Team of specialists"
								})] })]
							})
						]
					})
				})]
			}), /* @__PURE__ */ jsxs("div", {
				className: "text-center",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "text-xs uppercase tracking-[0.2em] text-orange font-bold mb-4",
						children: "About Bedifly"
					}),
					/* @__PURE__ */ jsxs("h2", {
						className: "text-4xl md:text-5xl font-extrabold text-navy-deep leading-[1.1]",
						children: [
							"We don't do ",
							/* @__PURE__ */ jsx("span", {
								className: "line-through text-muted-foreground",
								children: "vanity metrics"
							}),
							".",
							" ",
							/* @__PURE__ */ jsx("br", {}),
							"We do ",
							/* @__PURE__ */ jsx("span", {
								className: "text-gradient-orange",
								children: "revenue."
							})
						]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-6 text-muted-foreground text-lg leading-relaxed",
						children: "Bedifly is a full-stack performance marketing agency built for founders who care about profit, not just clicks. From strategy and media buying to creative production, our in-house team owns the whole growth funnel — so you don't have to juggle five vendors."
					}),
					/* @__PURE__ */ jsx("div", {
						className: "mt-8 space-y-4",
						children: [
							"Senior strategists on every account — no juniors, no handoffs.",
							"Weekly transparent reporting on ROAS, CAC and LTV.",
							"In-house creative studio shipping 30+ ads per month."
						].map((t) => /* @__PURE__ */ jsxs("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ jsx(TrendingUp, { className: "h-5 w-5 text-orange shrink-0 mt-0.5" }), /* @__PURE__ */ jsx("p", {
								className: "text-foreground/90",
								children: t
							})]
						}, t))
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/data/landing-data.ts
var clients = [
	{
		name: "Indian Property Expert",
		logo: "/assets/indian-property-expert-51HVA9kX.jpeg"
	},
	{
		name: "New Life Therapy",
		logo: "/assets/new-life-therapy-BAD_Ll51.png"
	},
	{
		name: "Padmakshi Jewels",
		logo: "/assets/padmakshi-jewels-BDyLdY5F.png"
	},
	{
		name: "Aneri Creation",
		logo: "/assets/aneri-creation-C1W_a0cn.png"
	},
	{
		name: "Just Real Estate",
		logo: "/assets/just-real-estate-C-O9ouFP.png"
	},
	{
		name: "Aawartan Construction",
		logo: "/assets/aawartan-construction-D38iAieR.png"
	},
	{
		name: "Tirth Travels & Holiday",
		logo: "/assets/tirth-travels-mY1HeWRX.jpeg"
	},
	{
		name: "Shanti Juniors",
		logo: "/assets/shanti-juniors-OjL-txD5.png"
	},
	{
		name: "IANT",
		logo: "/assets/iant-SkmfpL6q.png"
	},
	{
		name: "Pin Point Astrology",
		logo: "/assets/pin-point-astrology-ZStncRH9.png"
	}
];
var testimonials = [
	{
		quote: "I am a channel partner in real estate business and I tried earlier lead generation packages from so many companies like 99 acre and more but nothing worked — less than 5% site visits. But after Bedifly, the quality improved a lot — more than 25% site visits and around 3% conversion rate. My business skyrocketed. Everyone should try at least once.",
		name: "Vijay Desai",
		role: "Founder, Indian Property Expert"
	},
	{
		quote: "Bedifly ke saath kaam karke humein lead quality mein kaafi achha improvement dekhne ko mila. Pehle bahut saare leads sirf enquiry tak hi limited rehte the, lekin ab lagbhag 20% leads site visit tak pahunch rahe hain aur 2% ke aas-paas booking conversion mil raha hai. Sabse achhi baat yeh hai ki unka focus sirf lead quantity par nahi, balki genuine buyers lane par hota hai.",
		name: "Narendra Sharma",
		role: "Founder, Puja Realty"
	},
	{
		quote: "Travel business always depends on social media engagement and Bedifly knows it very well because of their high engagement reels and Meta ads expertise. I generated 10,000 leads in last 4 months with conversion rate of 5%.",
		name: "Amit Khare",
		role: "Founder, Lake Tours & Travels"
	},
	{
		quote: "Must try — they are very good in it whatever they do. I am in interior designing business, converting more than 5 clients per month with a project cost around 15 lac+.",
		name: "Divya Jamini",
		role: "Founder, Aristo Spaces"
	},
	{
		quote: "We are into the loan industry, needing clients all over India for above ₹1 crore residential and commercial loans. Ashutosh sir has helped us a lot in getting loan files at a very affordable lead cost — conversion rate above 4% and we are getting a ROAS of around 1:9 right now.",
		name: "Vishal Reddy",
		role: "Founder, Akshat Financial Services"
	}
];
//#endregion
//#region src/components/brands.tsx
function Brands() {
	const sliderClients = [...clients, ...clients];
	return /* @__PURE__ */ jsxs("section", {
		id: "brands",
		className: "py-20 px-6 overflow-hidden",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "max-w-6xl mx-auto text-center",
			children: [
				/* @__PURE__ */ jsx("div", {
					className: "text-[11px] uppercase tracking-[0.18em] text-orange font-bold mb-3",
					children: "Trusted by"
				}),
				/* @__PURE__ */ jsxs("h2", {
					className: "text-4xl md:text-5xl font-extrabold text-navy-deep",
					children: ["Brands we're scaling ", /* @__PURE__ */ jsx("span", {
						className: "text-gradient-brand",
						children: "right now."
					})]
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-4 text-sm md:text-base text-muted-foreground max-w-xl mx-auto",
					children: "From new companies to established brands."
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "relative mt-10 overflow-hidden",
					children: [
						/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-background to-transparent z-10" }),
						/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-background to-transparent z-10" }),
						/* @__PURE__ */ jsx("div", {
							className: "flex w-max",
							style: { animation: "brandSlider 35s linear infinite" },
							children: sliderClients.map((c, i) => /* @__PURE__ */ jsxs("div", {
								className: "group mx-2 w-[220px] md:w-[260px] h-[190px] rounded-2xl border border-border bg-card px-6 py-6 hover:border-orange hover:shadow-glow transition-all flex flex-col items-center justify-center gap-3",
								children: [/* @__PURE__ */ jsx("div", {
									className: "h-24 w-full flex items-center justify-center",
									children: /* @__PURE__ */ jsx("img", {
										src: c.logo,
										alt: `${c.name} logo`,
										className: "max-h-20 max-w-[85%] object-contain",
										loading: "lazy"
									})
								}), /* @__PURE__ */ jsx("div", {
									className: "text-sm font-display font-semibold text-navy-deep/80 group-hover:text-navy-deep tracking-wide text-center",
									children: c.name
								})]
							}, `${c.name}-${i}`))
						})
					]
				})
			]
		}), /* @__PURE__ */ jsx("style", { children: `
        @keyframes brandSlider {
          from {
            transform: translateX(-50%);
          }

          to {
            transform: translateX(0);
          }
        }
      ` })]
	});
}
//#endregion
//#region src/components/testimonials.tsx
function Testimonials() {
	const sliderTestimonials = [...testimonials, ...testimonials];
	return /* @__PURE__ */ jsxs("section", {
		id: "reviews",
		className: "relative py-20 px-6 bg-hero overflow-hidden",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "max-w-6xl mx-auto",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "text-center max-w-2xl mx-auto",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "text-[11px] uppercase tracking-[0.18em] text-orange font-bold mb-3",
						children: "What founders say"
					}),
					/* @__PURE__ */ jsxs("h2", {
						className: "text-4xl md:text-5xl font-extrabold text-navy-deep",
						children: ["Real results. ", /* @__PURE__ */ jsx("span", {
							className: "text-gradient-orange",
							children: "Real founders."
						})]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-4 text-sm md:text-base text-muted-foreground",
						children: "What businesses say about working with Bedifly."
					})
				]
			}), /* @__PURE__ */ jsxs("div", {
				className: "relative mt-10 overflow-hidden",
				children: [
					/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute left-0 top-0 bottom-0 w-16 md:w-24 bg-gradient-to-r from-background to-transparent z-10" }),
					/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute right-0 top-0 bottom-0 w-16 md:w-24 bg-gradient-to-l from-background to-transparent z-10" }),
					/* @__PURE__ */ jsx("div", {
						className: "flex w-max",
						style: { animation: "testimonialSlider 45s linear infinite" },
						children: sliderTestimonials.map((t, i) => /* @__PURE__ */ jsxs("div", {
							className: "glass mx-2 w-[290px] md:w-[330px] h-[270px] shrink-0 rounded-2xl p-6 shadow-soft hover:shadow-navy transition-all flex flex-col",
							children: [
								/* @__PURE__ */ jsx("div", {
									className: "flex gap-0.5 text-orange",
									children: Array.from({ length: 5 }).map((_, k) => /* @__PURE__ */ jsx(Star, { className: "h-3.5 w-3.5 fill-current" }, k))
								}),
								/* @__PURE__ */ jsxs("p", {
									className: "mt-4 text-sm text-foreground leading-relaxed line-clamp-5",
									children: [
										"\"",
										t.quote,
										"\""
									]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "mt-auto flex items-center gap-3 pt-5 border-t border-border",
									children: [/* @__PURE__ */ jsx("div", {
										className: "h-10 w-10 shrink-0 rounded-full bg-orange-gradient text-white grid place-items-center font-bold shadow-glow",
										children: t.name[0]
									}), /* @__PURE__ */ jsxs("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ jsx("div", {
											className: "text-sm font-semibold text-navy-deep",
											children: t.name
										}), /* @__PURE__ */ jsx("div", {
											className: "text-[11px] text-muted-foreground truncate",
											children: t.role
										})]
									})]
								})
							]
						}, `${t.name}-${i}`))
					})
				]
			})]
		}), /* @__PURE__ */ jsx("style", { children: `
        @keyframes testimonialSlider {
          from {
            transform: translateX(-50%);
          }

          to {
            transform: translateX(0);
          }
        }
      ` })]
	});
}
//#endregion
//#region src/components/contact-form.tsx
function ContactForm() {
	const [sent, setSent] = useState(false);
	const [submitting, setSubmitting] = useState(false);
	return /* @__PURE__ */ jsx("section", {
		id: "contact",
		className: "relative py-20 px-6",
		children: /* @__PURE__ */ jsxs("div", {
			className: "max-w-6xl mx-auto grid md:grid-cols-[0.9fr_1fr] gap-8 lg:gap-10 items-center",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "text-left",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "text-[11px] uppercase tracking-[0.18em] text-orange font-bold mb-3",
						children: "Let's talk"
					}),
					/* @__PURE__ */ jsxs("h2", {
						className: "text-4xl md:text-[46px] font-extrabold text-navy-deep leading-[1.05]",
						children: ["Ready to ", /* @__PURE__ */ jsx("span", {
							className: "text-gradient-orange",
							children: "grow 10x?"
						})]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-4 text-sm md:text-base text-muted-foreground leading-relaxed max-w-md",
						children: "Tell us about your brand. We'll get back within 24 hours with an honest, no-fluff plan for the next 90 days."
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-7 max-w-lg space-y-1",
						children: [
							/* @__PURE__ */ jsx(ContactRow, {
								icon: MapPin,
								title: "Ahmedabad Office",
								children: "4th Floor, C Wing, Krish Cubical, Thaltej, Ahmedabad"
							}),
							/* @__PURE__ */ jsx(ContactRow, {
								icon: MapPin,
								title: "Indore Office",
								children: "4th Floor, Mangal City, Vijay Nagar, Indore"
							}),
							/* @__PURE__ */ jsx(ContactRow, {
								icon: Mail,
								title: "Email",
								children: "info@bedifly.com"
							}),
							/* @__PURE__ */ jsx(ContactRow, {
								icon: Phone,
								title: "Phone",
								children: "+91 97524 73349"
							})
						]
					})
				]
			}), /* @__PURE__ */ jsxs("form", {
				onSubmit: async (e) => {
					e.preventDefault();
					if (submitting) return;
					setSubmitting(true);
					const form = e.currentTarget;
					const fd = new FormData(form);
					const { submitLead } = await import("./leads-webhook-BSkkmzp3.js");
					const res = await submitLead({
						name: String(fd.get("name") ?? ""),
						company: String(fd.get("company") ?? ""),
						email: String(fd.get("email") ?? ""),
						mobile: String(fd.get("mobile") ?? ""),
						city: String(fd.get("city") ?? "")
					});
					setSubmitting(false);
					if (res.ok) {
						setSent(true);
						toast.success("Thank you! Your details have been submitted.");
						form.reset();
					} else toast.error(res.error ?? "Something went wrong. Please try again or call us directly.");
				},
				className: "glass rounded-[1.75rem] p-6 md:p-7 shadow-navy",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "grid sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ jsx(Field, {
									label: "Full name",
									name: "name",
									placeholder: "Ridhima Shah",
									required: true
								}), /* @__PURE__ */ jsx(Field, {
									label: "Company",
									name: "company",
									placeholder: "Luméa Skincare"
								})]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "grid sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ jsx(Field, {
									label: "Mobile number",
									name: "mobile",
									type: "tel",
									placeholder: "+91 98765 43210",
									required: true
								}), /* @__PURE__ */ jsx(Field, {
									label: "City",
									name: "city",
									placeholder: "Ahmedabad"
								})]
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Email",
								name: "email",
								type: "email",
								placeholder: "you@brand.com",
								required: true
							})
						]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-5 space-y-3",
						children: [/* @__PURE__ */ jsx("button", {
							type: "submit",
							disabled: submitting,
							className: "w-full bg-navy-deep hover:bg-navy text-white rounded-full px-6 py-3.5 text-sm font-semibold shadow-navy hover:shadow-glow transition-all inline-flex items-center justify-center gap-2 disabled:opacity-70 cursor-pointer",
							children: sent ? "Thanks — we'll be in touch ✨" : submitting ? "Sending…" : /* @__PURE__ */ jsxs(Fragment, { children: ["Send message", /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })] })
						}), /* @__PURE__ */ jsxs("a", {
							href: "tel:+919752473349",
							className: "w-full bg-orange-gradient text-white rounded-full px-6 py-3.5 text-sm font-semibold shadow-glow hover:opacity-95 transition-all inline-flex items-center justify-center gap-2",
							children: [/* @__PURE__ */ jsx(Phone, { className: "h-4 w-4" }), "Call now: +91 97524 73349"]
						})]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-4 text-[11px] text-muted-foreground text-center",
						children: "By submitting, you agree to be contacted by Bedifly. We never share your info."
					})
				]
			})]
		})
	});
}
function ContactRow({ icon: Icon, title, children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "group flex items-center gap-3 rounded-xl px-2 py-2.5 transition-all duration-300 hover:bg-white/60",
		children: [/* @__PURE__ */ jsx("div", {
			className: "h-9 w-9 rounded-xl bg-orange-gradient text-white grid place-items-center shrink-0 shadow-glow",
			children: /* @__PURE__ */ jsx(Icon, {
				className: "h-4 w-4",
				strokeWidth: 2
			})
		}), /* @__PURE__ */ jsxs("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ jsx("div", {
				className: "text-sm font-bold text-navy-deep leading-5",
				children: title
			}), /* @__PURE__ */ jsx("div", {
				className: "text-xs md:text-sm text-muted-foreground leading-5",
				children
			})]
		})]
	});
}
function Field({ label, name, type = "text", placeholder, required }) {
	return /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("label", {
		htmlFor: name,
		className: "block text-[10px] font-bold text-navy-deep mb-1.5 uppercase tracking-wider",
		children: [label, required && /* @__PURE__ */ jsx("span", {
			className: "text-orange ml-1",
			children: "*"
		})]
	}), /* @__PURE__ */ jsx("input", {
		id: name,
		name,
		type,
		placeholder,
		required,
		className: "w-full rounded-xl border border-border bg-white/70 px-4 py-2.5 text-sm text-navy-deep placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-orange/50 focus:border-orange transition"
	})] });
}
//#endregion
//#region src/components/footer.tsx
function Footer() {
	return /* @__PURE__ */ jsx("footer", {
		className: "bg-navy-deep text-primary-foreground/80 px-6 pt-20 pb-10",
		children: /* @__PURE__ */ jsxs("div", {
			className: "max-w-6xl mx-auto",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "grid md:grid-cols-4 gap-10",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "md:col-span-2",
						children: [/* @__PURE__ */ jsx(BrandLogo, { light: true }), /* @__PURE__ */ jsx("p", {
							className: "mt-5 max-w-sm text-white/60 text-sm leading-relaxed",
							children: "Bedifly is a performance marketing agency helping ambitious founders grow 10x with paid ads, creative and SEO that compounds."
						})]
					}),
					/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
						className: "text-white font-semibold mb-4",
						children: "Company"
					}), /* @__PURE__ */ jsxs("ul", {
						className: "space-y-2 text-sm",
						children: [
							/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
								href: "#about",
								className: "hover:text-orange transition",
								children: "About"
							}) }),
							/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
								href: "#services",
								className: "hover:text-orange transition",
								children: "Services"
							}) }),
							/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
								href: "#reviews",
								className: "hover:text-orange transition",
								children: "Reviews"
							}) }),
							/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
								href: "#contact",
								className: "hover:text-orange transition",
								children: "Contact"
							}) })
						]
					})] }),
					/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
						className: "text-white font-semibold mb-4",
						children: "Offices"
					}), /* @__PURE__ */ jsxs("ul", {
						className: "space-y-3 text-sm text-white/60",
						children: [/* @__PURE__ */ jsx("li", { children: "Ahmedabad — 4th Floor, C Wing, Krish Cubical, Thaltej" }), /* @__PURE__ */ jsx("li", { children: "Indore — 4th Floor, Mangal City, Vijay Nagar" })]
					})] })
				]
			}), /* @__PURE__ */ jsx("div", {
				className: "mt-14 pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-white/50",
				children: /* @__PURE__ */ jsxs("div", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Bedifly. All rights reserved."
				] })
			})]
		})
	});
}
//#endregion
//#region src/routes/index.tsx?tsr-split=component
function Landing() {
	return /* @__PURE__ */ jsxs("div", {
		className: "min-h-screen bg-background text-foreground overflow-x-hidden",
		children: [
			/* @__PURE__ */ jsx(Nav, {}),
			/* @__PURE__ */ jsx(Hero, {}),
			/* @__PURE__ */ jsx(WhyBedifly, {}),
			/* @__PURE__ */ jsx(Services, {}),
			/* @__PURE__ */ jsx(GrowthSystem, {}),
			/* @__PURE__ */ jsx(CaseStudies, {}),
			/* @__PURE__ */ jsx(About, {}),
			/* @__PURE__ */ jsx(Brands, {}),
			/* @__PURE__ */ jsx(Testimonials, {}),
			/* @__PURE__ */ jsx(ContactForm, {}),
			/* @__PURE__ */ jsx(Footer, {})
		]
	});
}
//#endregion
export { Landing as component };
