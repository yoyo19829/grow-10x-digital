import { t as Route } from "./_slug-CGXKnjsk.js";
import { t as Nav } from "./nav-C197z1EM.js";
import { useEffect, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/blogs/$slug.tsx?tsr-split=component
function BlogPostPage() {
	const { slug } = Route.useParams();
	const [post, setPost] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(false);
	useEffect(() => {
		async function fetchPost() {
			try {
				const response = await fetch(`https://www.bedifly.com/wp-json/wp/v2/posts?slug=${encodeURIComponent(slug)}&_embed`);
				if (!response.ok) throw new Error("Failed to fetch blog");
				const data = await response.json();
				if (!data.length) throw new Error("Blog not found");
				setPost(data[0]);
			} catch (err) {
				console.error("WordPress blog error:", err);
				setError(true);
			} finally {
				setLoading(false);
			}
		}
		fetchPost();
	}, [slug]);
	if (loading) return /* @__PURE__ */ jsxs("main", {
		className: "min-h-screen bg-hero",
		children: [/* @__PURE__ */ jsx(Nav, {}), /* @__PURE__ */ jsx("div", {
			className: "pt-40 text-center text-muted-foreground",
			children: "Loading article..."
		})]
	});
	if (error || !post) return /* @__PURE__ */ jsxs("main", {
		className: "min-h-screen bg-hero",
		children: [/* @__PURE__ */ jsx(Nav, {}), /* @__PURE__ */ jsx("div", {
			className: "min-h-screen flex items-center justify-center px-6",
			children: /* @__PURE__ */ jsxs("div", {
				className: "text-center",
				children: [/* @__PURE__ */ jsx("h1", {
					className: "text-3xl font-bold text-navy-deep",
					children: "Article not found"
				}), /* @__PURE__ */ jsx("a", {
					href: "/blogs",
					className: "inline-block mt-5 text-orange font-semibold",
					children: "← Back to blogs"
				})]
			})
		})]
	});
	const image = post._embedded?.["wp:featuredmedia"]?.[0]?.source_url;
	const imageAlt = post._embedded?.["wp:featuredmedia"]?.[0]?.alt_text || post.title.rendered;
	const category = post._embedded?.["wp:term"]?.[0]?.[0]?.name || "Business Growth";
	const date = new Date(post.date).toLocaleDateString("en-IN", {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
	return /* @__PURE__ */ jsxs("main", {
		className: "min-h-screen bg-hero",
		children: [/* @__PURE__ */ jsx(Nav, {}), /* @__PURE__ */ jsx("article", {
			className: "px-5 sm:px-6 pt-28 md:pt-32 pb-20",
			children: /* @__PURE__ */ jsxs("div", {
				className: "max-w-6xl mx-auto",
				children: [
					/* @__PURE__ */ jsxs("header", {
						className: "max-w-4xl mx-auto text-center",
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "inline-flex items-center rounded-full border border-orange/20 bg-white/60 px-4 py-2 text-[11px] uppercase tracking-[0.18em] text-orange font-bold",
								children: category
							}),
							/* @__PURE__ */ jsx("h1", {
								className: "mt-6 text-4xl sm:text-5xl md:text-6xl font-extrabold text-navy-deep leading-[1.08] tracking-tight",
								dangerouslySetInnerHTML: { __html: post.title.rendered }
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-6 flex flex-wrap justify-center items-center gap-x-3 gap-y-2 text-sm text-muted-foreground",
								children: [
									/* @__PURE__ */ jsxs("span", { children: ["Published ", date] }),
									/* @__PURE__ */ jsx("span", {
										className: "hidden sm:inline",
										children: "•"
									}),
									/* @__PURE__ */ jsx("span", { children: "Bedifly Insights" })
								]
							})
						]
					}),
					image && /* @__PURE__ */ jsx("div", {
						className: "max-w-5xl mx-auto mt-10 md:mt-12 overflow-hidden rounded-[1.75rem] shadow-soft",
						children: /* @__PURE__ */ jsx("img", {
							src: image,
							alt: imageAlt,
							className: "block w-full h-auto object-cover"
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "mt-12 md:mt-16",
						children: /* @__PURE__ */ jsx("div", {
							className: "blog-content",
							dangerouslySetInnerHTML: { __html: post.content.rendered }
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "max-w-3xl mx-auto mt-16 pt-8 border-t border-border",
						children: /* @__PURE__ */ jsx("a", {
							href: "/blogs",
							className: "inline-flex items-center text-sm font-semibold text-navy-deep hover:text-orange transition-colors",
							children: "← Back to all blogs"
						})
					})
				]
			})
		})]
	});
}
//#endregion
export { BlogPostPage as component };
