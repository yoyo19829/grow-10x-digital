import { t as Nav } from "./nav-C197z1EM.js";
import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/blogs/index.tsx?tsr-split=component
function BlogsPage() {
	const [posts, setPosts] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(false);
	useEffect(() => {
		async function fetchBlogs() {
			try {
				const response = await fetch("https://www.bedifly.com/wp-json/wp/v2/posts?status=publish&per_page=12&_embed");
				if (!response.ok) throw new Error("Failed to fetch blogs");
				const data = await response.json();
				setPosts(data);
			} catch (err) {
				console.error("WordPress API error:", err);
				setError(true);
			} finally {
				setLoading(false);
			}
		}
		fetchBlogs();
	}, []);
	return /* @__PURE__ */ jsxs("main", {
		className: "min-h-screen bg-hero",
		children: [/* @__PURE__ */ jsx(Nav, {}), /* @__PURE__ */ jsx("section", {
			className: "px-6 pt-32 pb-20",
			children: /* @__PURE__ */ jsxs("div", {
				className: "max-w-6xl mx-auto",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "text-center max-w-3xl mx-auto",
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "text-[11px] uppercase tracking-[0.18em] text-orange font-bold mb-3",
								children: "Insights"
							}),
							/* @__PURE__ */ jsxs("h1", {
								className: "text-4xl md:text-5xl font-extrabold text-navy-deep",
								children: ["Bedifly ", /* @__PURE__ */ jsx("span", {
									className: "text-gradient-orange",
									children: "Blogs"
								})]
							}),
							/* @__PURE__ */ jsx("p", {
								className: "mt-4 text-sm md:text-base text-muted-foreground",
								children: "Practical insights on marketing, AI, websites, lead generation, and business growth."
							})
						]
					}),
					loading && /* @__PURE__ */ jsx("div", {
						className: "mt-12 text-center text-muted-foreground",
						children: "Loading blogs..."
					}),
					error && /* @__PURE__ */ jsx("div", {
						className: "mt-12 text-center text-muted-foreground",
						children: "Unable to load blogs right now. Please try again later."
					}),
					!loading && !error && /* @__PURE__ */ jsx("div", {
						className: "mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
						children: posts.map((post) => /* @__PURE__ */ jsx(BlogCard, { post }, post.id))
					})
				]
			})
		})]
	});
}
function BlogCard({ post }) {
	const image = post._embedded?.["wp:featuredmedia"]?.[0]?.source_url;
	const category = post._embedded?.["wp:term"]?.[0]?.[0]?.name || "Business Growth";
	const excerpt = post.excerpt.rendered.replace(/<[^>]*>/g, "").replace(/&hellip;/g, "...").replace(/&#8217;/g, "'").replace(/&#8220;/g, "\"").replace(/&#8221;/g, "\"").replace(/&#038;/g, "&");
	const date = new Date(post.date).toLocaleDateString("en-IN", {
		day: "numeric",
		month: "short",
		year: "numeric"
	});
	return /* @__PURE__ */ jsxs("article", {
		className: "group overflow-hidden rounded-[1.5rem] border border-border bg-card shadow-soft hover:shadow-navy hover:-translate-y-1 transition-all",
		children: [image && /* @__PURE__ */ jsx("div", {
			className: "aspect-[16/9] overflow-hidden",
			children: /* @__PURE__ */ jsx("img", {
				src: image,
				alt: post.title.rendered,
				className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
			})
		}), /* @__PURE__ */ jsxs("div", {
			className: "p-6",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ jsx("div", {
						className: "text-[10px] uppercase tracking-wider font-bold text-orange",
						children: category
					}), /* @__PURE__ */ jsx("div", {
						className: "text-[11px] text-muted-foreground",
						children: date
					})]
				}),
				/* @__PURE__ */ jsx("h2", {
					className: "mt-3 text-xl font-bold text-navy-deep leading-tight",
					dangerouslySetInnerHTML: { __html: post.title.rendered }
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-3 text-sm text-muted-foreground leading-relaxed line-clamp-3",
					children: excerpt
				}),
				/* @__PURE__ */ jsx(Link, {
					to: "/blogs/$slug",
					params: { slug: post.slug },
					className: "inline-flex mt-5 text-sm font-semibold text-navy-deep hover:text-orange transition-colors",
					children: "Read article →"
				})
			]
		})]
	});
}
//#endregion
export { BlogsPage as component };
